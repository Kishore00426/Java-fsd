package assist5;
public class finaldemo {
	    public static void main(String[] args) {
	        final int x = 10;
	        // x = 20; // Error: Cannot assign a value to final variable 'x'

	        final double PI = 3.14;
	        // PI = 3.14159; // Error: Cannot assign a value to final variable 'PI'

	        final String message = "Hello";
	        // message = "Hi"; // Error: Cannot assign a value to final variable 'message'

	        final MyClass obj = new MyClass();
	        obj.printMessage(); // Output: Hello World
	        // obj = new MyClass(); // Error: Cannot assign a value to final variable 'obj'
	    }
	}

	class MyClass {
	    public final void printMessage() {
	        System.out.println("Hello World");
	    }

}

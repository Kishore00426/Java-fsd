package assist2;
class BankAccount {
    private double balance;

    public BankAccount() {
        this.balance = 0;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited: " + amount);
        System.out.println("Balance after deposit: " + balance);

        synchronized (this) {
            if (balance > 1000) {
                try {
                    System.out.println("Balance exceeds threshold. Waiting for withdrawal...");
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void withdraw(double amount) {
        synchronized (this) {
            if (balance >= amount) {
                balance -= amount;
                System.out.println("Withdrawn: " + amount);
                System.out.println("Balance after withdrawal: " + balance);

                if (balance <= 1000) {
                    System.out.println("Threshold reached. Notifying deposit thread...");
                    notify();
                }
            } else {
                System.out.println("Insufficient balance for withdrawal");
            }
        }
    }
}

class DepositThread implements Runnable {
    private BankAccount account;

    public DepositThread(BankAccount account) {
        this.account = account;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            account.deposit(500);
        }
    }
}

class WithdrawThread implements Runnable {
    private BankAccount account;

    public WithdrawThread(BankAccount account) {
        this.account = account;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            account.withdraw(800);
        }
    }
}

public class  waitdemo{
    public static void main(String[] args) {
        BankAccount account = new BankAccount();

        Thread depositThread = new Thread(new DepositThread(account));
        Thread withdrawThread = new Thread(new WithdrawThread(account));

        depositThread.start();
        withdrawThread.start();
    }


}


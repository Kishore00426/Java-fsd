package assist1;

class Printer1 implements Runnable {
    
    @Override
    public void run() {
        System.out.println("Thread created by Runnable interface extension");
    }
}

public class Runnableinterface {

    public static void main(String[] args) {
        Printer1 p1 = new Printer1();
        Thread t = new Thread(p1);
        t.start();
    }
}


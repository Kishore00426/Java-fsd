package assist4;
public class TryCatch {
	    public static void main(String[] args) {
	        try {
	            int[] numbers = {1, 2, 3, 4, 5};
	            int index = 6;
	            int result = numbers[index];
	            System.out.println("The result is: " + result);
	        } catch (ArrayIndexOutOfBoundsException e) {
	            System.out.println("Array index out of bounds exception occurred!");
	        }
	    }


}

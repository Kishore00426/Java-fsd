package pro.com;
import java.util.*;
public class Teeset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> ts=new TreeSet<String>();
		ts.add("a");
		ts.add("b");
		ts.add("c");
		ts.add("c");
		System.out.println(ts);
	}

}
